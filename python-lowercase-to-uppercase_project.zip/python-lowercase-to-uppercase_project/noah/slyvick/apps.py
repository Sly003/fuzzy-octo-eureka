from django.apps import AppConfig


class SlyvickConfig(AppConfig):
    name = 'slyvick'
